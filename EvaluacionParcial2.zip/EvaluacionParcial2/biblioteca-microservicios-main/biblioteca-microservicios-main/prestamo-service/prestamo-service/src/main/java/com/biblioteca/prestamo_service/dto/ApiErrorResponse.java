package com.biblioteca.prestamo_service.dto;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import lombok.Builder;
import lombok.Data; 
@Data
@Builder
public class ApiErrorResponse {
    private LocalDateTime timestamp;
    private Integer status;
    private String error;
    private String message;
    private String path;
    @Builder.Default
    private List<String> errors = new ArrayList<>();
}


