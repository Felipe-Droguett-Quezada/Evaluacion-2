package com.biblioteca.prestamo_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrestamoServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
